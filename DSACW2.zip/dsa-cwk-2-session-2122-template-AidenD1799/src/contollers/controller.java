package contollers;

import daos.bstDAOImpl;
import helpers.InputHelper;
import helpers.OutputHelper;
import helpers.TextColours;
import model.DisplayOrder;
import model.StudentMarks;


public class controller {
    // Add your variables here
    private final InputHelper inputHelper;
    private bstDAOImpl<StudentMarks> bstDAO;
    private StudentMarks studentMarks;

    public controller() {
        // Add your code here
        this.inputHelper = new InputHelper();
        this.bstDAO = new bstDAOImpl<>();
        this.studentMarks = new StudentMarks();
    }

    /**
     * Displays the menu and uses an InputHelper object
     * to accept valid user choice.
     * An appropriate private method is called to implement the choice.
     */
    public void run() {
        boolean finished = false;

        int iChoice;
        this.setup();

        do {
            this.theMenu();
            iChoice = inputHelper.readInt("Enter choice", 5,1);
            switch (iChoice) {
                // Add more cases
                case 1:
                    System.out.println("Displaying Ascending");
                    displayTreeInAscendingOrder();
                    break;
                case 2:
                    System.out.println("Displaying Descending");
                    displayTreeInDescendingOrder();
                    break;
                case 3:
                    System.out.println("Find Student by Module Mark");
                    findData();
                    break;
                case 4:
                    bstDAO.displayBSTChart();
                    break;
                case 5:
                    System.out.println(TextColours.TEXT_RED + "Exiting Program...");

                    finished = true;
                    break;
                default: // invalid option
                    System.out.println("Oops! Something has went wrong!");
                    break;
            }
        }while(!finished);
    }
    private void theMenu() {
        // Print menu to console
        System.out.println(TextColours.TEXT_RESET + "1. Display Ascending");
        System.out.println("2. Display Descending");
        System.out.println("3. Find Student by Module Mark");
        System.out.println("4. Bar Chart");
        System.out.println("5. Exit Program");
        // Add your code here
    }
    /**
        *Displays the student's data in ascending order of module mark
     */
    private void displayTreeInAscendingOrder()
    {
        System.out.println(TextColours.TEXT_CYAN + "Display Terms in ascending order");
        System.out.println("--------------------------------");
        this.bstDAO.displayBST(DisplayOrder.ASCENDING);
    }

    /**
     * Displays the student's data in descending order of module mark
     */
    private void displayTreeInDescendingOrder()
    {
        System.out.println(TextColours.TEXT_PURPLE + "Display Data in Descending Order");
        System.out.println("--------------------------------");
        this.bstDAO.displayBST(DisplayOrder.DESCENDING);
    }

    /**
     * Searches the data tree for a student with the same module mark
     */
    private void findData()
    {
        System.out.println(TextColours.TEXT_YELLOW + "Find a Student by Module Mark");
        System.out.println("-------------");
        String aMark =inputHelper.readString( "Please enter the student's Module Mark  ");
        this.bstDAO.findData(Integer.parseInt(aMark));
    }

    private void setup(){
        this.bstDAO.loadFromFile("ClassTestData.txt");
    }

}
