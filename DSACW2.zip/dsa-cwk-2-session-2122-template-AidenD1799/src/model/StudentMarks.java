package model;

import java.util.ArrayList;

public class StudentMarks implements Comparable<StudentMarks>{
    // Add your variables here
    private String StudentID;
    private String FirstName;
    private String LastName;
    private int FirstMark;
    private int SecondMark;
    private int ThirdMark;
    private int ModuleMark;
    private String ModuleMarkAsBar;
    private ArrayList<Integer> marksList;
    public StudentMarks(){
        // Add your code here
        this.StudentID = "";
        this.FirstName = "";
        this.LastName = "";
        this.FirstMark = 0;
        this.SecondMark = 0;
        this.ThirdMark = 0;
        this.ModuleMark = 0;
        this.ModuleMarkAsBar = "";
    }

    public StudentMarks(String studentID, String firstName, String lastName, Integer firstMark, Integer secondMark, Integer thirdMark, Integer moduleMark)
    {
        this.StudentID = studentID;
        this.FirstName =  firstName;
        this.LastName = lastName;
        this.FirstMark = firstMark;
        this.SecondMark = secondMark;
        this.ThirdMark = thirdMark;
        this.ModuleMark = moduleMark;
    }

    public String getStudentID() {
        return this.StudentID;
    }

    public void setStudentID(String studentID) {
        this.StudentID = studentID;
    }

    public String getFirstName() {
        return this.FirstName;
    }

    public void setFirstName(String firstName) {
        this.FirstName = firstName;
    }

    public String getLastname() {
        return this.LastName;
    }

    public void setLastname(String lastname) {
        this.LastName = lastname;
    }

    public int getFirstMark() {
          return this.FirstMark;
    }

    public void setFirstMark(int firstMark) {
        this.FirstMark = firstMark;
    }

    public int getSecondMark() {
        return this.SecondMark;
    }

    public void setSecondMark(int secondMark) {
        this.SecondMark = secondMark;
    }

    public int getThirdMark() {
        return this.ThirdMark;
    }

    public void setThirdMark(int thirdMark) {
        this.ThirdMark = thirdMark;
    }

    public int getModuleMark() {
        return this.ModuleMark ;  // Add your return type here
    }

    public void setModuleMark(int moduleMark) {
        this.ModuleMark = moduleMark;
    }

    public String getModuleMarkAsBar(){return this.ModuleMarkAsBar; }

    public void setModuleMarkAsBar(String moduleMarkAsBar){this.ModuleMarkAsBar = moduleMarkAsBar;}

    public ArrayList getMarksList()
    {
        return this.marksList;
    }

    public int calculateModuleMark(){
        double moduleMark = ((getFirstMark() * 0.3) + (getSecondMark() * 0.3) + (getThirdMark() * 0.4));
        return (int) moduleMark;
    }

    /**
     * This is used to calculate each student's module marks
     * @param firstMark
     * @param secondMark
     * @param thirdMark
     * @return
     */
    public int calculateModuleMark(int firstMark, int secondMark, int thirdMark)
    {
        double moduleMark = (firstMark * 0.3 + secondMark * 0.3 + thirdMark * 0.4);
        return (int) moduleMark;
    }

    public String CSVFormat(){
        String outputString = this.StudentID + ", " + this.FirstName + ", " + this.LastName + ", " + this.FirstMark + ", " + this.SecondMark + ", " + this.ThirdMark + ", " + this.ModuleMark;
        return outputString;
    }

    @Override
    public String toString() {
        return "StudentMarks{" +
                '}';
    }

    @Override
    public int compareTo(StudentMarks anEntry) {
        return this.ModuleMark - anEntry.ModuleMark;
    }


}
