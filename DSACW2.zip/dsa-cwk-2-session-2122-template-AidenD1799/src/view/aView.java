package view;

import datastructures.BinarySearchTree;
import datastructures.Node;
import helpers.InputHelper;
import helpers.OutputHelper;
import helpers.TextColours;
import model.DisplayOrder;
import model.StudentMarks;

public class aView {
    private StudentMarks studentMarks;
    private InputHelper inputHelper;

    /**
     * Sorts and displays the terms in ascending order
     * @param root
     */
    public void displayBSTItemAsc(Node<StudentMarks> root){
        if (root.leftNode != null) {
            displayBSTItemAsc(root.leftNode);
        }
        System.out.format("| %-30s | %-30s | %-30s | %-30s | %-30s | %-30s | %-30s |\n", root.getNodeData().getStudentID(), root.getNodeData().getFirstName(), root.getNodeData().getLastname(), root.getNodeData().getFirstMark(), root.getNodeData().getSecondMark(), root.getNodeData().getThirdMark(), root.getNodeData().getModuleMark());
        if(root.rightNode != null){
            displayBSTItemAsc(root.rightNode);
        }
    }

    /**
     * Sorts and displays the terms in descending order
     * @param root
     */
    public void displayBSTItemDesc(Node<StudentMarks> root){
        if(root.rightNode != null){

            displayBSTItemDesc((root.rightNode));
        }
        System.out.format("| %-30s | %-30s | %-30s | %-30s | %-30s | %-30s | %-30s |\n", root.getNodeData().getStudentID(), root.getNodeData().getFirstName(),
                root.getNodeData().getLastname(), root.getNodeData().getFirstMark(), root.getNodeData().getSecondMark(), root.getNodeData().getThirdMark(), root.getNodeData().getModuleMark());
        if(root.leftNode != null){
            displayBSTItemDesc(root.leftNode);
        }
    }

    public void displayBST(BinarySearchTree<StudentMarks> theBST, DisplayOrder order){
        System.out.println(OutputHelper.repeat("-", 230));
        System.out.format("| %-30s | %-30s | %-30s | %-30s | %-30s | %-30s | %-30s |\n", "StudentID", "FirstName", "Last Name", "First Mark", "Second Mark", "Third Mark", "Module Mark");
        System.out.println(OutputHelper.repeat("-", 230));
        if(order == DisplayOrder.ASCENDING)
        {
            displayBSTItemAsc(theBST.getRoot());
        }
        else{
            displayBSTItemDesc(theBST.getRoot());
        }
        System.out.println(OutputHelper.repeat("-", 230));
    }

    /**
     * Displays a specific data entry from the BST
     * @param anItem
     */
    public void displayABSTItem(StudentMarks anItem){
        System.out.println(OutputHelper.repeat("-", 230));
        System.out.format("| %-30s | %-30s | %-30s | %-30s | %-30s | %-30s | %-30s |\n", "StudentID", "FirstName", "Last Name", "First Mark", "Second Mark", "Third Mark", "Module Mark");
        System.out.println(OutputHelper.repeat("-", 230));
        System.out.format("| %-30s | %-30s | %-30s | %-30s | %-30s | %-30s | %-30s |\n", anItem.getStudentID(), anItem.getFirstName(),
               anItem.getLastname(), anItem.getFirstMark(), anItem.getSecondMark(), anItem.getThirdMark(), anItem.getModuleMark());
        System.out.println(OutputHelper.repeat("-", 230));
    }

    /**
     * Displays a student's score as a bar
     * @param root
     */
    public void displayStudentScoreInChart(Node<StudentMarks> root){
        if (root.leftNode != null)
        {
            displayStudentScoreInChart(root.leftNode);
        }
        System.out.format(TextColours.TEXT_GREEN + "%-10s | %-100s \n", root.getNodeData().getStudentID(), root.getNodeData().getModuleMarkAsBar());
        if(root.leftNode != null)
        {
            displayStudentScoreInChart(root.rightNode);
        }
    }

    /**
     * Displays the full bar chart in correct format
     * @param theBst
     */
    public void displayAsChart(BinarySearchTree <StudentMarks> theBst){
        displayStudentScoreInChart(theBst.getRoot());
        System.out.println(OutputHelper.repeat("-", 120));
        System.out.format("%-20s %-9s %-9s %-9s %-9s %-9s %-9s %-9s %-9s %-9s %-9s \n", "Marks", 10, 20, 30, 40, 50, 60, 70, 80, 90, 100);
    }

}
