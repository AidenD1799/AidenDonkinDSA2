package daos;

import app.StudentMarksBST;
import datastructures.BinarySearchTree;
import helpers.OutputHelper;
import helpers.Sorts;
import helpers.TextColours;
import model.DisplayOrder;
import model.StudentMarks;
import view.aView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.File;
import java.io.FileWriter;

public class bstDAOImpl<E> extends DAO<E>{

    private BinarySearchTree<StudentMarks> theBST;
    private aView theView;
    public static final char DELIMITER = ',';
    public static final char EOLN='\n';
    public static final String QUOTE="\"";
    public static final String USERDIRECTORY = System.getProperty("user.dir");

    private String stripQuotes(String str) {
        return str.substring(1, str.length()-1);
    }

    public bstDAOImpl() {
        // Add your code here
        this.theBST = new BinarySearchTree<>();
        this.theView = new aView();
    }

    public BinarySearchTree<StudentMarks> getTheBST() {
        return theBST;
    }

    public void setTheBST(BinarySearchTree<StudentMarks> theBST) {
        this.theBST = theBST;
    }

    /**
     * Reads the data from the ClassTestData.txt file and sorts it into the correct order
     * @param filename
     */
    @Override
    public void loadFromFile(String filename) {
        String transactionFile = USERDIRECTORY +"\\" + filename;
        // Add your variables here
        ArrayList <StudentMarks> dataSet = new ArrayList<>();
        Sorts <StudentMarks> sort = new Sorts<>();

        try (BufferedReader br = new BufferedReader(new FileReader(transactionFile))) {
            // Add your variables here
            String theStudentID;
            String theFirstName;
            String theLastName;
            int theFirstMark;
            int theSecondMark;
            int theThirdMark;
            int theModuleMark;
            String[] temp;
            String line = br.readLine();
            while(line!=null){
                // split each line and store the values in your variables
                temp=line.split(Character.toString(DELIMITER));
                theStudentID = temp[0];
                theFirstName = temp[1];
                theLastName = temp[2];
                theFirstMark = Integer.parseInt((temp[3]));
                theSecondMark = Integer.parseInt(temp[4]);
                theThirdMark = Integer.parseInt(temp[5]);



                // Create required instances of your modelled data
                StudentMarks aStudent = new StudentMarks();
                aStudent.setStudentID(theStudentID);
                aStudent.setFirstName(theFirstName);
                aStudent.setLastname(theLastName);
                aStudent.setFirstMark(theFirstMark);
                aStudent.setSecondMark(theSecondMark);
                aStudent.setThirdMark(theThirdMark);
                theModuleMark = aStudent.calculateModuleMark(theFirstMark, theSecondMark, theThirdMark);
                aStudent.setModuleMark(theModuleMark);
                aStudent.setModuleMarkAsBar(StringRepeater(theModuleMark));



                // Insert into the dataset
                dataSet.add(aStudent);
                line = br.readLine();

            }
            br.close();
        } catch (IOException ex) {
            Logger.getLogger(StudentMarksBST.class.getName()).log(Level.INFO, null, ex);
        }
        // sort the dataset
        sort.BSort(dataSet);

        // create a balanced tree
        this.theBST.createBalancedTree(dataSet, 0, dataSet.size() - 1);


    }

    @Override
    public void writeToFile(String filename) {

    }


    public void writeToFile(String filename, StudentMarks data ) throws IOException {

        try {
            File myFile = new File(USERDIRECTORY +"\\" + filename);
            FileWriter myWriter = new FileWriter(myFile.getName());
            myWriter.write(data.CSVFormat());

            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    @Override
    public void add(E theData) {
        this.theBST.addNode((StudentMarks) theData);
    }

    @Override
    public void update(E theData) {

    }

    /**
     * Used to search the BST by module mark for the correct student
     * @param theData
     */
    @Override
    public void findData(int theData) {
        StudentMarks dataToFind = new StudentMarks("", "", "", 0, 0, 0, theData);
        StudentMarks found = theBST.findItem(dataToFind);
        if (found != null)
        {
            this.theView.displayABSTItem(found);
        }
        else{
            System.out.format("The entry %s was %s found!\n", theData, TextColours.TEXT_RED + "not" + TextColours.TEXT_RESET);
        }
    }

    @Override
    public E getData(String theData) {
        return null;
    }

    @Override
    public void removeData(int theData) {
        // Add your code here
    }

    public void displayBST(DisplayOrder order){
        this.theView.displayBST(this.theBST, order);
    }

    /**
     * Used to display the bar chart which contains the students module marks shown as bars
     */
    public void displayBSTChart(){
        System.out.println("Display Data as a Chart");
        System.out.println(OutputHelper.repeat("-", 22));
        this.theView.displayAsChart(this.theBST);
    }

    /**
     * used to convert module marks into * bars for the bar chart
     * @param moduleMarks
     * @return
     */
    public String StringRepeater(Integer moduleMarks)
    {
        String toRepeat = "*";
        String repeated = new String(new char[moduleMarks]).replace("\0", toRepeat);
        return repeated;
    }

}
